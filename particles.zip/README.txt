A Pen created at CodePen.io. You can find this one at https://codepen.io/eltonkamami/pen/ECrKd.

 They just move,if they find a 'friend' they get bigger